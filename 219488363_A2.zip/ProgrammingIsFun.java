package com.gmail.bazookasiphesihle;
import javax.swing.JOptionPane; //Programming is fun
public class ProgrammingIsFun 
{
     public static void main(String [] args) 
	{
		JOptionPane.showMessageDialog(null,"Programming is fun");
	    System.exit(0);
	}
}